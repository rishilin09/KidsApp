import { Injectable } from '@angular/core';
import { Leaderboard } from './interfaces';

@Injectable({
  providedIn: 'root'
})

export class LeaderboardService {
  constructor() { }

  leaderboard: Leaderboard[] = [];
  
  addLeaderBoard(leaderboard: Leaderboard){
    this.leaderboard.push(leaderboard);
  }

  getLeaderBoard(){
    console.log(this.leaderboard);
    return this.leaderboard;
  }


}
