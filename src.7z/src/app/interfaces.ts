export interface Leaderboard {
    desc: string;
    date: Date;
    answers: Answers[];
}

export interface Answers {
    name: String;
    selected: String;
}

export interface Animal {
    name: String;
    letters: string[];
    img: String;
}
